
CREATE DATABASE scm DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
CREATE USER 'scm'@'localhost' IDENTIFIED WITH mysql_native_password BY 'scm@Scm123';
GRANT ALL PRIVILEGES ON scm.* TO 'scm'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE USER 'scm'@'%' IDENTIFIED WITH mysql_native_password BY 'scm@Scm123';
GRANT ALL PRIVILEGES ON scm.* TO 'scm'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE USER 'scm'@'192.168.1.200' IDENTIFIED WITH mysql_native_password BY 'scm@Scm123';
GRANT ALL PRIVILEGES ON scm.* TO 'scm'@'192.168.1.200' WITH GRANT OPTION;
FLUSH PRIVILEGES;



CREATE DATABASE rman DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
CREATE USER 'rman'@'%' IDENTIFIED WITH mysql_native_password BY 'rman@Rman123';
GRANT ALL PRIVILEGES ON rman.* TO 'rman'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;



CREATE USER 'rman'@'localhost' IDENTIFIED WITH mysql_native_password BY 'rman@Rman123';
GRANT ALL PRIVILEGES ON rman.* TO 'rman'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE USER 'rman'@'192.168.1.200' IDENTIFIED WITH mysql_native_password BY 'rman@Rman123';
GRANT ALL PRIVILEGES ON rman.* TO 'rman'@'192.168.1.200' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE DATABASE hue DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
CREATE USER 'hue'@'%' IDENTIFIED WITH mysql_native_password BY 'hue@Hue123';
GRANT ALL PRIVILEGES ON hue.* TO 'hue'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE USER 'hue'@'localhost' IDENTIFIED WITH mysql_native_password BY 'hue@Hue123';
GRANT ALL PRIVILEGES ON hue.* TO 'hue'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE USER 'hue'@'192.168.1.200' IDENTIFIED WITH mysql_native_password BY 'hue@Hue123';
GRANT ALL PRIVILEGES ON hue.* TO 'hue'@'192.168.1.200' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE DATABASE metastore DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
CREATE USER 'hive'@'%' IDENTIFIED WITH mysql_native_password BY 'hive@Hive123';
GRANT ALL PRIVILEGES ON metastore.* TO 'hive'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE USER 'hive'@'localhost' IDENTIFIED WITH mysql_native_password BY 'hive@Hive123';
GRANT ALL PRIVILEGES ON metastore.* TO 'hive'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE USER 'hive'@'192.168.1.200' IDENTIFIED WITH mysql_native_password BY 'hive@Hive123';
GRANT ALL PRIVILEGES ON metastore.* TO 'hive'@'192.168.1.200' WITH GRANT OPTION;
FLUSH PRIVILEGES;



CREATE DATABASE sentry DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
CREATE USER 'sentry'@'%' IDENTIFIED WITH mysql_native_password BY 'sentry@Sentry123';
GRANT ALL PRIVILEGES ON sentry.* TO 'sentry'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE USER 'sentry'@'localhost' IDENTIFIED WITH mysql_native_password BY 'sentry@Sentry123';
GRANT ALL PRIVILEGES ON sentry.* TO 'sentry'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE USER 'sentry'@'192.168.1.200' IDENTIFIED WITH mysql_native_password BY 'sentry@Sentry123';
GRANT ALL PRIVILEGES ON sentry.* TO 'sentry'@'192.168.1.200' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE DATABASE oozie DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
CREATE USER 'oozie'@'%' IDENTIFIED WITH mysql_native_password BY 'oozie@Oozie123';
GRANT ALL PRIVILEGES ON oozie.* TO 'oozie'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE USER 'oozie'@'localhost' IDENTIFIED WITH mysql_native_password BY 'oozie@Oozie123';
GRANT ALL PRIVILEGES ON oozie.* TO 'oozie'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE USER 'oozie'@'192.168.1.200' IDENTIFIED WITH mysql_native_password BY 'oozie@Oozie123';
GRANT ALL PRIVILEGES ON oozie.* TO 'oozie'@'192.168.1.200' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE DATABASE ranger DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
CREATE USER 'ranger'@'%' IDENTIFIED WITH mysql_native_password BY 'ranger@Ranger123';
GRANT ALL PRIVILEGES ON ranger.* TO 'ranger'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE USER 'ranger'@'localhost' IDENTIFIED WITH mysql_native_password BY 'ranger@Ranger123';
GRANT ALL PRIVILEGES ON ranger.* TO 'ranger'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;


CREATE USER 'ranger'@'192.168.1.200' IDENTIFIED WITH mysql_native_password BY 'ranger@Ranger123';
GRANT ALL PRIVILEGES ON ranger.* TO 'ranger'@'192.168.1.200' WITH GRANT OPTION;
FLUSH PRIVILEGES;
